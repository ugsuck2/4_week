import {useState} from 'react'

function Quiz01() {

    const [even, setEven] = useState(0);
    
    return(
        <div>
            <button onClick={()=>{
                console.log('count증가버튼클릭');
                
                
                setEven(even+2)   
                
                
                console.log(even);
            }}>count증가</button>
            <p>{even}</p>
        </div>
    )
}

export default Quiz01;