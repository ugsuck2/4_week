import './Quiz03.css'
import Recycle from './Recycle';



function Quiz03() {


    return (
        <div>
        <div>
            <Recycle title="제목" num="하나" text="내용하나" />
            <Recycle title="제목" num="둘" text="내용둘" />
            <Recycle title="제목" num="셋" text="내용셋" />
            <Recycle title="제목" num="넷" text="내용넷" />
            <Recycle title="제목" num="다섯" text="내용다섯" />
        </div>
        
        
        </div>
        );
}

export default Quiz03;